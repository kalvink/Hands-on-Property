function sendEmail(){
alert("Message Sent");
}
